const Property = require("../models/Property");
const { validationResult } = require("express-validator");



exports.uploadLease = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    if (!req.file) return res.status(400).json({ msg: "No file uploaded" });

    const { propertyId } = req.body;

    const property = await Property.findById(propertyId);
    if (!property) return res.status(404).json({ msg: "Property not found" });

    property.leaseDocument = `/uploads/${req.file.filename}`;
    await property.save();

    res.json({ msg: "Lease uploaded", property });
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
};