const Property = require("../models/Property");
const { validationResult } = require("express-validator");

// ➕ Add Property (Owner only)
exports.addProperty = async (req, res) => {
  try {
    const { title, location, rent } = req.body;
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const property = await Property.create({
      title,
      location,
      rent,
      owner: req.user.id,
    });

    res.status(201).json(property);
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
};

// 📥 Get All Properties
exports.getProperties = async (req, res) => {
  try {
    const properties = await Property.find().populate("owner", "name email");
    res.json(properties);
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
};

// ✏️ Update Property
exports.updateProperty = async (req, res) => {
  try {
    const property = await Property.findById(req.params.id);

    if (!property) {
      return res.status(404).json({ msg: "Property not found" });
    }

    // Only owner can update
    if (property.owner.toString() !== req.user.id) {
      return res.status(403).json({ msg: "Not authorized" });
    }

    Object.assign(property, req.body);
    await property.save();

    res.json(property);
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
};

// ❌ Delete Property
exports.deleteProperty = async (req, res) => {
  try {
    const property = await Property.findById(req.params.id);

    if (!property) {
      return res.status(404).json({ msg: "Property not found" });
    }

    if (property.owner.toString() !== req.user.id) {
      return res.status(403).json({ msg: "Not authorized" });
    }

    await property.deleteOne();

    res.json({ msg: "Property deleted" });
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
};

exports.assignTenant = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { tenantId, leaseStart, leaseEnd } = req.body;

    const property = await Property.findById(req.params.id);

    if (!property) {
      return res.status(404).json({ msg: "Property not found" });
    }

    if (property.owner.toString() !== req.user.id) {
      return res.status(403).json({ msg: "Not authorized" });
    }

    property.tenant = tenantId;
    property.leaseStart = leaseStart;
    property.leaseEnd = leaseEnd;

    await property.save();

    res.json({
      msg: "Tenant assigned",
      property,
    });
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
};