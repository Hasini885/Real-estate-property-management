const express = require("express");
const upload = require("../middleware/upload");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware");
const { uploadLease } = require("../controllers/leaseController");

const router = express.Router();

router.post(
  "/upload",
  authMiddleware,
  roleMiddleware("owner"),
  upload.single("file"),
  uploadLease
);

module.exports = router;