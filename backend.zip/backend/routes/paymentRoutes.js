const express = require("express");


const { addPayment, getPayments, createOrder, verifyPayment } = require("../controllers/paymentController");



const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware");

const router = express.Router();

router.post("/create-order", authMiddleware, createOrder);
//VerifyPayment
router.post("/verify", authMiddleware, verifyPayment);

// Tenant pays
router.post("/", authMiddleware, roleMiddleware("tenant"), addPayment);

// View payments (all logged-in users)
router.get("/", authMiddleware, getPayments);

module.exports = router;