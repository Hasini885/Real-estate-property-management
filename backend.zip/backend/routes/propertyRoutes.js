const express = require("express");
const {
  addProperty,
  getProperties,
  updateProperty,
  deleteProperty,
  assignTenant,
} = require("../controllers/propertyController");

const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware");

const router = express.Router();
// Owner only
router.post("/", authMiddleware, roleMiddleware("owner"), addProperty);

// All logged-in users
router.get("/", authMiddleware, getProperties);

router.put(
  "/assign/:id",
  authMiddleware,
  roleMiddleware("owner"),
  assignTenant
);

// Owner only
router.put("/:id", authMiddleware, roleMiddleware("owner"), updateProperty);
router.delete("/:id", authMiddleware, roleMiddleware("owner"), deleteProperty);

module.exports = router;